# Copilot Instructions for DayLog (updated)

This file contains the minimal, actionable knowledge an AI coding agent needs to be productive in DayLog.

**Project Purpose & Big Picture:**

- **What it is:** A cross-platform journaling app built with .NET MAUI + Blazor, storing content locally with EF Core (SQLite).
- **Why it’s structured this way:** Blazor inside a MAUI WebView provides reusable web components for UI while MAUI hosts native platform integration (files, app lifecycle).

**Where to start (must-read files):**

- `MauiProgram.cs`: DI container and service registrations; modify here when adding services or changing lifetimes.
- `MainPage.xaml.cs`: Initializes the Blazor WebView and root component (`Components/Routes.razor`).
- `Components/Routes.razor`: Router and app shell — useful to understand page navigation.

**Core subsystems & boundaries:**

- **UI layer:** `Components/` and `Pages/` contain Blazor components and page implementations (see `Components/Editor/QuillEditor.razor`).
- **Services:** Implement behavior and state in `Services/` with interfaces in `Services/Interfaces/` (e.g., `AuthService`, `SessionService`, `JournalService`).
- **Data layer:** `data/AppDbContext.cs` handles EF Core configuration and entity indexes. Entities live in `Entities/` and DTO/view-models in `Models/`.
- **Static/web assets:** `wwwroot/` holds CSS/JS (notably `wwwroot/js/quill-editor.js`) used by Blazor via JS interop.

**Repository-specific conventions and patterns:**

- **DI-first:** Register services in `MauiProgram.cs`; components and services depend on interfaces in `Services/Interfaces/`.
- **Session singleton:** `SessionService` is the canonical runtime session holder — use for cross-component state.
- **AppDbContext rules:** `SaveChanges()` applies timestamping. Unique constraints (tags, usernames) are declared in `OnModelCreating()` — add indexes there when you add entities.
- **JS Interop pattern:** `QuillEditor` uses `dotNetRef` callbacks in `Components/Editor/QuillEditor.razor` and `wwwroot/js/quill-editor.js`; mirror this for other editors/JS widgets.

**Build, run, and debug (practical commands):**

- Preferred: open the solution in Visual Studio and run the Windows MAUI target for full debugging (recommended for WebView + native interop).
- CLI: `dotnet build` from repository root to compile; use Visual Studio for Run/Debug on Windows.
- Platform edits & packaging: `Platforms/Windows/` contains manifests and packaging config.

**Database & migrations:**

- The app creates a local SQLite DB at runtime; local development does not require explicit EF migrations. When changing schema, update `data/AppDbContext.cs` and add migrations if you plan to ship changes across installs.

**Common change tasks (recipes):**

- Add a service: create interface in `Services/Interfaces/`, implement under `Services/`, register in `MauiProgram.cs`, then `@inject` it where needed.
- Add a page: add a Razor page in `Pages/Journal/`, update routes in `Components/Routes.razor`, and add a navigation link in `Components/Layout/NavMenu.razor`.

**Helpful places to inspect for examples:**

- `data/AppDbContext.cs` — model configuration, timestamps, uniqueness.
- `Components/Editor/QuillEditor.razor` and `wwwroot/js/quill-editor.js` — JS interop examples.
- `Services/JournalService/JournalService.cs` — typical service patterns and data mappings.

If you want, I can add short code templates for: adding a service, adding a page, or the JS interop stub used by `QuillEditor`.

# Copilot Instructions for DayLog

## Project Overview

DayLog is a cross-platform journaling app built with .NET MAUI and Blazor. It uses Entity Framework Core (SQLite) for local data storage and follows a modular component/service architecture. The app targets Windows and other platforms via MAUI.

## Architecture & Key Patterns

- **Entry Point:**
  - `MauiProgram.cs` configures services, database, and fonts. All DI registrations happen here.
  - `MainPage.xaml.cs` sets up the Blazor WebView and root component (`Components.Routes`).
- **UI Structure:**
  - Blazor components are organized under `Components/` and `Pages/`.
  - Layouts: `Components/Layout/MainLayout.razor` (main shell), `EmptyLayout.razor` (minimal shell).
  - Navigation is handled via `Components/Routes.razor` using Blazor's router.
- **Services:**
  - Registered in `MauiProgram.cs` using DI. Key services: `AuthService`, `SessionService`, `JournalService`.
  - Service interfaces are in `Services/Interfaces/`.
- **Data Layer:**
  - `data/AppDbContext.cs` defines EF Core context. Uses SQLite DB at app data path.
  - Entities: `Entities/` (e.g., `LogEntry`, `Tag`, `UserAuth`).

  # Copilot Instructions for DayLog (updated)

  This file contains the minimal, actionable knowledge an AI coding agent needs to be productive in DayLog.

  ## Quick templates (copy-paste)
  1. Registering a service (add to `MauiProgram.cs`)

  ```csharp
  // MauiProgram.cs (inside CreateMauiApp)
  builder.Services.AddScoped<IMyService, MyService>();
  // or singleton: builder.Services.AddSingleton<ISessionService, SessionService>();
  ```

  2. Add a new page + route and nav link

  ```razor
  // Pages/Journal/EntryEdit.razor
  @page "/Edit-entry"
  @inject IJournalService JournalService

  <h3>New Entry</h3>
  <p>Entry creation / edit page.</p>
  ```

  Add a nav link in `Components/Layout/NavMenu.razor`:

  ```razor
  <li class="nav-item">
    <NavLink class="nav-link" href="/Edit-entry">New Entry</NavLink>
  </li>
  ```

  3. JS interop stub (component + `wwwroot/js`)

  ```razor
  // Components/Editor/QuillEditor.razor (minimal)
  @inject IJSRuntime JS

  <div id="quill-editor"></div>

  @code {
    DotNetObjectReference<QuillEditor>? dotNetRef;

    protected override async Task OnAfterRenderAsync(bool firstRender)
    {
      if (firstRender)
      {
        dotNetRef = DotNetObjectReference.Create(this);
        await JS.InvokeVoidAsync("quillInterop.init", "#quill-editor", dotNetRef);
      }
    }

    [JSInvokable]
    public Task OnQuillChange(string html)
    {
      // handle html
      return Task.CompletedTask;
    }
  }
  ```

  ```javascript
  // wwwroot/js/quill-editor.js
  window.quillInterop = {
    init: function (selector, dotNetRef) {
      const el = document.querySelector(selector);
      if (!el) return;
      const quill = new Quill(el, { theme: "snow" });
      quill.on("text-change", function () {
        dotNetRef.invokeMethodAsync("OnQuillChange", quill.root.innerHTML);
      });
    },
  };
  ```

  ## Project overview (short)
  - **What it is:** A cross-platform journaling app built with .NET MAUI + Blazor, storing content locally with EF Core (SQLite).
  - **Where to start:** `MauiProgram.cs`, `MainPage.xaml.cs`, `Components/Routes.razor`.

  ## Key patterns (short)
  - **DI-first:** register services in `MauiProgram.cs` and depend on interfaces in `Services/Interfaces/`.
  - **Session:** `SessionService` is a singleton used for runtime state.
  - **EF Core:** `data/AppDbContext.cs` manages timestamps and unique indexes in `OnModelCreating()`.
  - **JS Interop:** follow the `dotNetRef` pattern used by `QuillEditor`.

  ## Build & debug
  - Preferred: open the solution in Visual Studio and run the Windows MAUI target.
  - CLI: `dotnet build` from repo root to compile.

  ## Where to look for examples
  - `data/AppDbContext.cs`
  - `Components/Editor/QuillEditor.razor` and `wwwroot/js/quill-editor.js`
  - `Services/JournalService/JournalService.cs`

  If you want, I can (1) create the sample files for you, (2) run a local build, or (3) walk step-by-step to run the app in Visual Studio — tell me which and I'll proceed.
