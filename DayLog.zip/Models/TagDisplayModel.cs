﻿// Models/TagDisplayModel.cs
namespace DayLog.Models
{
    public class TagDisplayModel
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
    }
}
